# Pacientes e seus tempos de atendimento
pacientes = {
    'Maria Clara': 80,
    'Pedro Henrique': 90,
    'Ana Luiza': 60,
    'Gabriel Oliveira': 70,
    'Laura Beatriz': 45,
    'João Miguel': 80,
    'Isabela Fernandes': 65,
    'Lucas Santos': 85,
    'Beatriz Almeida': 75
}

# Horários de atendimento por dia
horarios = {
    'Segunda': (8, 13),   # 8h às 13h
    'Quarta': (18, 22),   # 18h às 22h
    'Sexta': (14, 17)     # 14h às 17h
}

# Agendamento por dia
agendamento = {
    'Segunda': [],
    'Quarta': [],
    'Sexta': []
}

# Loop para alocar os pacientes em cada dia
for dia, horario in horarios.items():
    hora_inicio, hora_fim = horario
    tempo_disponivel = (hora_fim - hora_inicio) * 60  # Converter horas para minutos

    tempo_atual = 0
    pacientes_agendados = []
    
    for paciente, tempo_atendimento in pacientes.items():
        if tempo_atual + tempo_atendimento <= tempo_disponivel:
            inicio = hora_inicio * 60 + tempo_atual
            fim = inicio + tempo_atendimento
            pacientes_agendados.append((paciente, inicio, fim))
            tempo_atual += tempo_atendimento
        else:
            break  # Interrompe o loop quando o tempo disponível é atingido

    agendamento[dia] = pacientes_agendados

    # Remove os pacientes já alocados
    for paciente, _, _ in pacientes_agendados:
        del pacientes[paciente]

# Imprimir agendamento
for dia, pacientes_agendados in agendamento.items():
    if len(pacientes_agendados) > 0:
        print(f'Agendamento para {dia}:')
        for paciente, inicio, fim in pacientes_agendados:
            hora_inicio = inicio // 60
            min_inicio = inicio % 60
            hora_fim = fim // 60
            min_fim = fim % 60
            print(f'{dia}: {hora_inicio:02d}:{min_inicio:02d} - {hora_fim:02d}:{min_fim:02d} - {paciente}')
        print('-----')
    else:
        print(f'Nenhum paciente alocado para {dia}.')
