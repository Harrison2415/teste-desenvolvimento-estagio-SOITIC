document.addEventListener("DOMContentLoaded", function() {
  var pacientes = [
    { nome: "Maria Clara", tempoAtendimento: 80 },
    { nome: "Pedro Henrique", tempoAtendimento: 90 },
    { nome: "Ana Luiza", tempoAtendimento: 60 },
    { nome: "Gabriel Oliveira", tempoAtendimento: 70 },
    { nome: "Laura Beatriz", tempoAtendimento: 45 },
    { nome: "João Miguel", tempoAtendimento: 80 },
    { nome: "Isabela Fernandes", tempoAtendimento: 65 },
    { nome: "Lucas Santos", tempoAtendimento: 85 },
    { nome: "Beatriz Almeida", tempoAtendimento: 75 },
    { nome: "Matheus Costa", tempoAtendimento: 90 }
  ];

  var diasAtendimento3 = ["Segunda", "Quarta", "Sexta"];

  var totalHorasDia3 = [];

  for (var i = 0; i < diasAtendimento3.length; i++) {
    var totalHorasDia = 0;
    for (var j = i * 3; j < (i + 1) * 3; j++) {
      totalHorasDia += pacientes[j].tempoAtendimento;
    }
    totalHorasDia3.push(totalHorasDia);
  }

  var chartData3 = {
    labels: diasAtendimento3,
    datasets: [
      {
        label: "Total de Horas por (3 Dias)",
        data: totalHorasDia3,
        backgroundColor: "rgba(54, 162, 235, 0.5)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1
      }
    ]
  };

  var chartOptions = {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  var ctx1 = document.getElementById("chart1").getContext("2d");

  var chart1 = new Chart(ctx1, {
    type: "bar",
    data: chartData3,
    options: chartOptions
  });

});
