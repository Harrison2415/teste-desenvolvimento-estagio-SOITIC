var clientes = []; // Cria um array vazio para armazenar os dados dos clientes

			// Define uma função para adicionar um novo cliente
			function addCliente() {

				// Obtém os valores dos campos do formulário
				var dataAtendimento = document.getElementById("dataAtendimento").value;
				var nome = document.getElementById("nome").value;
				var dataNascimento = document.getElementById("dataNascimento").value;
				var telefone = document.getElementById("telefone").value;

				// Cria um objeto com os dados do cliente
				var novoCliente = {
					dataAtendimento: dataAtendimento,
					nome: nome,
					dataNascimento: dataNascimento,
					telefone: telefone
				};

				// Adiciona o objeto cliente ao array de clientes
				clientes.push(novoCliente);

				// Atualiza a tabela com os dados dos clientes
				atualizarTabela();

				// Retorna false para evitar que a página seja recarregada após o envio do formulário
				return false;
			}

			function removerCliente(index) { // Define a função `removerCliente`, que recebe um índice como parâmetro
				clientes.splice(index, 1); // Remove o cliente correspondente ao índice `index` do array `clientes`
				atualizarTabela(); // Atualiza a tabela na página
			}

			function atualizarTabela() {
				var tabela = document.getElementById("clientes"); // Recupera a tabela da página pelo seu ID
				tabela.innerHTML = ""; // Limpa o conteúdo da tabela

				for (var i = 0; i < clientes.length; i++) { // Percorre o array de clientes
					var cliente = clientes[i]; // Recupera o cliente da posição i do array

					var linha = document.createElement("tr"); // Cria uma nova linha na tabela

					// Cria novas colunas com a data de atendimento, nome, data de nascimento, telefone e a coluna da ação
					var colunaDataAtendimento = document.createElement("td");
					var colunaNome = document.createElement("td");
					var colunaDataNasc = document.createElement("td");
					var colunaTelefone = document.createElement("td");
					var colunaAcao = document.createElement("td");

					// Define os conteúdos das colunas
					colunaDataAtendimento.innerHTML = cliente.dataAtendimento;
					colunaNome.innerHTML = cliente.nome;
					colunaDataNasc.innerHTML = cliente.dataNascimento;
					colunaTelefone.innerHTML = cliente.telefone;

					var botaoRemover = document.createElement("button"); // Cria um novo botão para remover o cliente
					botaoRemover.innerHTML = "Remover"; // Define o texto do botão

					botaoRemover.onclick = (function(index) { // Define o evento de clique do botão
						return function() {
							removerCliente(index); // Chama a função para remover o cliente
						}
					})(i);

					colunaAcao.appendChild(botaoRemover); // Adiciona o botão de remover na coluna de ação
					linha.appendChild(colunaDataAtendimento); // Adiciona a coluna da data de atendimento na linha
					linha.appendChild(colunaNome); // Adiciona a coluna do nome na linha
					linha.appendChild(colunaDataNasc); // Adiciona a coluna da data de nascimento na linha
					linha.appendChild(colunaTelefone); // Adiciona a coluna do telefone na linha
					linha.appendChild(colunaAcao); // Adiciona a coluna de ação na linha

					tabela.appendChild(linha); // Adiciona a linha na tabela
				}
			}